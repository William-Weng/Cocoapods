//
//  NSObject+William.h
//  Wheel
//
//  Created by engineer on 2017/1/13.
//  Copyright © 2017年 William-Weng. All rights reserved.
//

#import <Foundation/Foundation.h>

#define RadiansToDegrees(radians) ((radians) * (180.0 / M_PI))
#define DegreesToRadians(degrees) ((degrees) / 180.0 * M_PI)

@interface NSObject (William)

@end
